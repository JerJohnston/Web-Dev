# contrast
Add CSS styling to this simple HTML page to bring in the principles of contrast. Think carefully about what elements you want to stand out and bring attention to, and what elements can fade into the background. What's the hierarchy order of the headings, ie, what's your focal points? Does that show visually? You can edit the HTML if needed, but the content, titles, and images must remain the same.

List 2 things you purposely did to create effective contrast.

When finished rename the project folder to contrast-username, zip up the folder and upload to Moodle for submission.  Be sure to include your list of 2 things in the online text area. Late submissions will not be accepted for marking.
